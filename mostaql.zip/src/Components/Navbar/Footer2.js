import React from 'react';
const Footer = () => {

  return (
    <div className='footer11' style={{}}>
        <p>
          جميع الحقوق محفوظة 2023©
          </p>
        <a href="http://www.mrsgt.com/" style={{textDecoration:'none'}}>
          <p style={{color:"rgb(74,153,233)"}}>برمجة م. مدحت رشاد سعيد</p>  
        </a> 
    </div>
  )
}

export default Footer;